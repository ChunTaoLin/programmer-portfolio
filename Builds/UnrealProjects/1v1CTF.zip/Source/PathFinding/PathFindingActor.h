// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GridActor.h"
#include "SteeringActor.h"
#include "Containers/Queue.h"
#include "PathFindingActor.generated.h"

UCLASS()
class PATHFINDING_API  APathFindingActor : public ASteeringActor
{
	GENERATED_BODY()

public:	

	// Contructors
	APathFindingActor();

	// Destructors
	~APathFindingActor();

	// Built-in functions
	virtual void Tick(float DeltaTime) override;




	// Accesor Functions ----------------------------------------------- //

	int FindBestIndex(TArray<FGridNode> openList, FGridNode endNode);

	UFUNCTION(BlueprintCallable) void FindPath(const FVector2D& startPos, const FVector2D& endPos, UPARAM(ref) TArray<FVector>& pathArray);

	// ----------------------------------------------------------------- //

protected:




	// Vairables ------------------------------------------------------- //
	
	// TArray's
	UPROPERTY(EditAnywhere, BlueprintReadWrite) AGridActor* GridActor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite) TArray<FVector> Path;

	// Booleans
	bool once = true;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) bool NeedNewDestination = true;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) bool useDjikstra = true;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) bool findNewPath = true;

	// Floats
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float ReachRadius = 100.0f;

	// ----------------------------------------------------------------- //




	// Accesor Functions ----------------------------------------------- //

	int CalculateHeuristic(FGridNode node, FGridNode endNode);
	// ----------------------------------------------------------------- //




	// Mutator Functions ----------------------------------------------- //
	TArray<FGridNode>FindNeighbors(FGridNode startingNode);



};