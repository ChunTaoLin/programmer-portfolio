// Fill out your copyright notice in the Description page of Project Settings.


#include "PathFindingActor.h"
#include "Kismet/KismetMathLibrary.h"

// This is the constructor for the class
APathFindingActor::APathFindingActor() 
{
}





// This is the destructor for the class
APathFindingActor::~APathFindingActor() 
{
	GridActor = nullptr;
	delete GridActor;
}





// This function gets called every tick
void APathFindingActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// Does the actor need a new destination?
	if (NeedNewDestination)
	{	
		// If yes, then is the actors pending path pool greater than 0?
		if (Path.Num() > 0)
		{
			// If yes, then set it to active
			TargetPos = Path[0];
			Path.RemoveAt(0);
			NeedNewDestination = false;
		}
	}
	else
	{
		// If no, then check that the destination has not yet been reached
		float distanceToDestination = (Position - TargetPos).Size();
		if (distanceToDestination <= ReachRadius)
		{
			NeedNewDestination = true;
		}
	}
}


// This function finds a path between two given start and end positions
void APathFindingActor::FindPath(const FVector2D& startPos, const FVector2D& endPos, UPARAM(ref) TArray<FVector>& pathArray)
{
	// Reset the grid to its original value
	GridActor->ResetGridValues();

	// Is the start position equal to the end position?
	if (startPos.X == endPos.X &&
		startPos.Y == endPos.Y)
	{
		// If yes, then return nothing
		return;
	}

	//makes sure the destination is valid
	if (FMath::RoundToInt(endPos.X) >= GridActor->GetGridSizeX() || FMath::RoundToInt(endPos.Y) >= GridActor->GetGridSizeY()
		|| FMath::RoundToInt(endPos.X) < 0 || FMath::RoundToInt(endPos.Y) < 0)
	{
		//if yes, then return nothing
		return;
	}

	if (GridActor->GetNode(endPos.X, endPos.Y).isWall == true)
	{
		// If yes, then return nothing
		return;
	}

	// Turn the start and end positions into full-on grid nodes
	FGridNode startNode = GridActor->GetNode(FMath::RoundToInt(startPos.X), FMath::RoundToInt(startPos.Y));
	FGridNode endNode = GridActor->GetNode(FMath::RoundToInt(endPos.X), FMath::RoundToInt(endPos.Y));

	int bestIndex = 0;
	int smallestNum = 10000;

	int distanceToNeighbor = 0;

	TArray<FGridNode> openList = TArray<FGridNode>();
	TArray<FGridNode> closeList = TArray<FGridNode>();
	TArray<FGridNode> neighbors = TArray<FGridNode>();

	FGridNode currentNode = FGridNode();

	startNode.isWall = GridActor->GetNode(startNode.x, startNode.y).isWall;

	startNode.x = startPos.X;
	startNode.y = startPos.Y;

	startNode.value = 0;

	startNode.position.X = GridActor->GetNode(startNode.x, startNode.y).position.X;
	startNode.position.Y = GridActor->GetNode(startNode.x, startNode.y).position.Y;

	GridActor->SetGridNodeValue(startNode.x, startNode.y, 0);

	openList.Add(startNode);


	// This while loop will continue to run until the entire open list has been emptied
	while (openList.Num() > 0)
	{
		// Find the best index from the open list
		bestIndex = FindBestIndex(openList, endNode);

		// Set the current node to the best node and make sure
		// to delete it from the open list and add it to the closed list
		currentNode = openList[bestIndex];
		openList.RemoveAt(bestIndex);
		closeList.Add(currentNode);

		// Get all neighbors of the best node
		neighbors = FindNeighbors(currentNode);
		distanceToNeighbor = currentNode.value + 1;


		//Search grid but only set neighbor if the visited node is a neighbor of current node, based on positions
		for (int i = 0; i < neighbors.Num(); i++)
		{
			// Has the neighbor been evaluated yet and is it not a wall?
			if (neighbors[i].value > distanceToNeighbor && neighbors[i].isWall == false)
			{
				// If yes, then add it to the open list with its correct value
				neighbors[i].value = distanceToNeighbor;
				GridActor->SetGridNodeValue(neighbors[i].x, neighbors[i].y, distanceToNeighbor);
				openList.Add(neighbors[i]);

			}
		}


		// Is the current node equal to the end node?
		if (currentNode.position == endNode.position)
		{
			// If yes, then start to back track

			TArray<FVector> path = TArray<FVector>();
			path.Add(currentNode.position);

			int countBeforeKick = 0;

			while (true)
			{
				// Find all neighbors of the current node
				neighbors = FindNeighbors(currentNode);

				//Search grid but only set neighbor if the visited node is a neighbor of current node, based on positions These searches the grid and makes sure the node is a neighbor of the currentNode
				for (int i = 0; i < neighbors.Num(); i++)
				{
					// is the current neighbor selected the smallest number and not a wall?
					if (neighbors[i].value < smallestNum && neighbors[i].isWall == false)
					{
						// If yes, then set it to the current node
						currentNode = neighbors[i];
						smallestNum = currentNode.value;
					}
				}

				if (path[path.Num() - 1] == currentNode.position)
				{

				}
				else if (path[path.Num() - 1] != currentNode.position && currentNode.isWall == false)
					// Add the current node to the path
					path.Add(currentNode.position);

				// Has the start node been reached?
				if (currentNode.x == startNode.x &&
					currentNode.y == startNode.y)
				{
					// If yes then invert the path
					for (int i = path.Num(); i > 0; i--)
					{
						pathArray.Add(path[i - 1]);
					}
					return;
				}

				if (path.Num() == 0)
				{
					return;
				}

				//Extra security feature
				countBeforeKick++;

				if (countBeforeKick > 30000)
				{
					return;
				}
			}

		}

	}
	// If the open list has been emptied and
	// there is still no match, return nothing
	return;
}


// This function finds the best index out of the current open list 
int APathFindingActor::FindBestIndex(TArray<FGridNode> openList, FGridNode endNode)
{
	float bestDist = 10000;
	int bestIndex = 1;

	// Cycle through the whole open list
	for (int i = 0; i < openList.Num(); i++)
	{
		// Is the open list's value less than the best distance?
		if (openList[i].value < bestDist)
		{
			// If yes, then set that index to the best index
			bestDist = openList[i].value;
			bestIndex = i;
		}
	}

	// Return result
	return bestIndex;
}





// This function calculates the heuristic for the A* algorithm
int APathFindingActor::CalculateHeuristic(FGridNode node, FGridNode endNode) 
{
	// This heuristic simply calculates the raw distance between itself and the end node
	int differenceX = FMath::Abs(node.x - endNode.x);
	int differenceY = FMath::Abs(node.y - endNode.y);
	return differenceX + differenceY;
}





//This function finds all of the neighbors of a given node
TArray<FGridNode> APathFindingActor:: FindNeighbors(FGridNode startingNode) 
{
	// Initialize values
	TArray<FVector2D> possibleNeighboors = TArray<FVector2D>();
	TArray<FGridNode> finalNeighboors = TArray<FGridNode>();

	// Find all posible neighbors
	possibleNeighboors.Add(FVector2D(startingNode.x + 1,startingNode.y));
	possibleNeighboors.Add(FVector2D(startingNode.x - 1,startingNode.y));
	possibleNeighboors.Add(FVector2D(startingNode.x, startingNode.y + 1));
	possibleNeighboors.Add(FVector2D(startingNode.x, startingNode.y - 1));


	// Cycle through possible neighbors list
	for (int i = 0; i < possibleNeighboors.Num(); i++) 
	{
		// Is this possible neighbor within range of the grid?
		if (possibleNeighboors[i].X >= 0 && possibleNeighboors[i].Y >= 0 && possibleNeighboors[i].X <= GridActor->GetGridSizeX() - 1 && possibleNeighboors[i].Y <= GridActor->GetGridSizeY() - 1) 
		{
			// If yes, then add it as an actual neighbor
			finalNeighboors.Add(GridActor->GetNode(possibleNeighboors[i].X, possibleNeighboors[i].Y));
			finalNeighboors[finalNeighboors.Num() -1].value = GridActor->GetNode(possibleNeighboors[i].X, possibleNeighboors[i].Y).value;
		}
	}

	// Return result
	return finalNeighboors;
}