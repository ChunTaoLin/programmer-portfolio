// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "PathFindingActor.h"
#include "Containers/Queue.h"
#include "StateMachine.generated.h"

UENUM(BlueprintType)		//"BlueprintType" is essential to include
enum class EStateEnums : uint8
{
	SE_Nothing 	UMETA(DisplayName = "Nothing"),
	SE_Idle 	UMETA(DisplayName = "Idle"),
	SE_Return 	UMETA(DisplayName = "Return"),
	SE_Grab		UMETA(DisplayName = "Grab"),
	SE_Shoot	UMETA(DisplayName = "Shoot"),
	SE_Chase	UMETA(DisplayName = "Chase"),
	SE_Avoid	UMETA(DisplayName = "Avoid")
};

UCLASS()
class PATHFINDING_API AStateMachine : public APathFindingActor
{
	GENERATED_BODY()
	
public:	

	// Sets default values for this actor's properties
	AStateMachine();

protected:

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// ----------------------------------------------------------------- //
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Enum)
	EStateEnums stateEnum;
};
