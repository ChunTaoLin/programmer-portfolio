// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GridActor.generated.h"

// This struct represents an individual grid node
USTRUCT()
struct FGridNode
{
	GENERATED_USTRUCT_BODY()

		// Integers
		UPROPERTY() int value;
	UPROPERTY() int x = 0;
	UPROPERTY() int y = 0;

	// Booleans
	UPROPERTY() bool isWall = false;

	// FVectors
	UPROPERTY() FVector position;
};


// This struct represents a row of grid nodes
USTRUCT()
struct FRowStruct
{
	GENERATED_USTRUCT_BODY()

		// TArray's
		UPROPERTY() TArray<FGridNode> _gridNode;
};

UCLASS()
class PATHFINDING_API AGridActor : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AGridActor();

	UFUNCTION(BlueprintCallable) void ResetWalls();
	UFUNCTION(BlueprintCallable) void ResetGridValues();
	FGridNode GetNode(int elementX, int elementY) { return Grid[elementX]._gridNode[elementY]; };
	int GetGridSizeX() { return gridSizeX; };
	int GetGridSizeY() { return gridSizeY; };
	int GetGridDisplacement() { return gridDisplacement; };
	UFUNCTION(BlueprintCallable) void SetGridNodeValue(const int& gridX, const int& gridY, const int& newValue);

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	UFUNCTION(BlueprintCallable) void SetGridNodeAsWall(const int& gridX, const int& gridY);
	UFUNCTION(BlueprintCallable) void GenerateGrid();
	UFUNCTION(BlueprintCallable) FVector GetGridNodePosition(const int& gridX, const int& gridY);
	UFUNCTION(BlueprintCallable) void AddWalls(const TArray<FVector2D>& walls);

	UPROPERTY(EditAnywhere, BlueprintReadWrite) float gridDisplacement = 1.0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float gridSizeX = 1.0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float gridSizeY = 1.0f;

	TArray<FRowStruct> Grid;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

};
