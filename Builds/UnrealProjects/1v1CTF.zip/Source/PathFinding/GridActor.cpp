// Fill out your copyright notice in the Description page of Project Settings.


#include "GridActor.h"

// Sets default values
AGridActor::AGridActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AGridActor::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void AGridActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// This function generates a grid for the actor to follow
void AGridActor::GenerateGrid()
{
	Grid = TArray<FRowStruct>();

	// Cycle through whole grid based on its proposed grid size
	for (int x = 0; x < gridSizeX; x++)
	{
		// Initialize a new row struct and add it to the grid
		FRowStruct _rowStruct = FRowStruct();
		Grid.Add(_rowStruct);

		for (int y = 0; y < gridSizeY; y++)
		{
			FGridNode newGridNode = FGridNode();

			// Initialize its evaluation value
			newGridNode.value = 10000;

			// Get the node's new position
			newGridNode.position = FVector(gridDisplacement * x, gridDisplacement * y, 0);

			// Get the node's position on the grid
			newGridNode.x = x;
			newGridNode.y = y;

			// Add to grid array
			Grid[x]._gridNode.Add(newGridNode);
		}
	}
}





// This accesor function gets the 3Dposition of a grid node based on its place in the grid (x and y) 
FVector AGridActor::GetGridNodePosition(const int& gridX, const int& gridY)
{
	return Grid[gridX]._gridNode[gridY].position;
}





// This function sets a grid node to a given value from a given position on the grid
void AGridActor::SetGridNodeValue(const int& gridX, const int& gridY, const int& newValue)
{
	Grid[gridX]._gridNode[gridY].value = newValue;
}





// This function sets a grid node as a wall from a given position on the grid
void AGridActor::SetGridNodeAsWall(const int& gridX, const int& gridY)
{
	Grid[gridX]._gridNode[gridY].isWall = true;
}



// This function go through the entire grid resets all of the values of the grid
void AGridActor::ResetGridValues()
{
	for (int i = 0; i < Grid.Num(); i++)
	{
		for (int j = 0; j < Grid[i]._gridNode.Num(); j++)
		{
			Grid[i]._gridNode[j].value = 10000;
		}
	}
}





// This function adds all of the walls to the grid to represent them during path finding
void AGridActor::AddWalls(const TArray<FVector2D>& walls)
{
	for (int i = 0; i < walls.Num(); i++)
	{
		Grid[walls[i].X]._gridNode[walls[i].Y].isWall = true;
	}
}





// This function goes through all nodes and makes sure that all of them are not walls
void AGridActor::ResetWalls()
{
	for (int x = 0; x < gridSizeX; x++)
	{
		for (int y = 0; y < gridSizeY; y++)
		{
			Grid[x]._gridNode[y].isWall = false;
		}
	}
}